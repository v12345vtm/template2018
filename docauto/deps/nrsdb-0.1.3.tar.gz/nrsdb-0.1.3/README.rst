NRSdb is the package for accessing NRS database

install:
    c:\Python27\Scripts\pip.exe install C:\Users\PGO\PycharmProjects\nrsdb

uninstall:
    c:\Python27\Scripts\pip.exe uninstall nrsdb

