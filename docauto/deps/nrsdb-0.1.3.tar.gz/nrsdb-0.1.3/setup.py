from setuptools import setup

def readme():
    with open('README.rst') as f:
        return f.read()

setup(name='nrsdb',
      version='0.1.3',
      description='Interface with NRS database',
      # url='http://github.com/storborg/funniest',
      author='Pablo Gomez',
      author_email='pablo.gomez@let.be',
      license='Propietary',
      packages=['nrsdb'],
      install_requires=['pymssql', ],
      zip_safe=False,
      long_description=readme(),
      classifiers=[
            'Development Status :: 3 - Alpha',
            'License :: Propietary',
            'Programming Language :: Python :: 2.7',
            'Topic :: Database management',
      ],
      )
