# noinspection PyUnresolvedReferences
import pymssql
import datetime

NRS_USERID = 31
DOCX_EXTENSION = '.docx'

CREDENTIALS = {
    31: {'user': 'docauto', 'password': '4b35.W7I2.'}
}

class NRSdb:

    host = 'file01'
    port = 50590

    # user = 'docauto'
    # password = '4b35.W7I2.'

    def __init__(self, userid=31):
        self.user = CREDENTIALS[userid]['user']
        self.password = CREDENTIALS[userid]['password']

        self.conn = pymssql.connect(host=self.host, port=self.port, user=self.user, password=self.password,
                                    autocommit=True)
        self.cursor = self.conn.cursor()

    def full_path_info_nrs_file(self, nrs_file):
        self.cursor.execute("SELECT "
                            "   bestandsdir, objectdataid, oudobjectdataid, "
                            "   CASE WHEN islinkfile IS NULL THEN 0 ELSE 1 END AS islinkfile, "
                            "   abs(isoudnr) AS isoudnr, "
                            "   abs(ismultibestand) as ismultibestand "
                            "FROM objectdata "
                            "WHERE ObjectDataID=%s OR OudObjectDataID=%s", (nrs_file, nrs_file))
        info = self.cursor.fetchall()
        info = info[0]
        return info

    def exists_nrs_file(self, nrs_file):
        self.cursor.execute("SELECT count(*) "
                            "FROM objectdata "
                            "WHERE ObjectDataID=%s OR oudObjectDataID=%s",
                            (nrs_file, nrs_file))
        exists = self.cursor.fetchall()
        exists = exists[0][0]
        if exists == 1:
            return True
        elif exists == 0:
            return False
        else:
            raise Exception("ERR: There is more than 1 entry in NRS for the file %s" % nrs_file)

    def related_nrs_file(self, masked_nrs_file):
        """
        Returns a list of registers which NRS identifiers are related to the requested nrs_file:
        different version or language
        """
        self.cursor.execute("SELECT "
                            "   bestandsdir, objectdataid, oudobjectdataid, islinkfile, "
                            "   CASE WHEN islinkfile IS NULL THEN 0 ELSE 1 END "
                            "FROM "
                            "   objectdata "
                            "WHERE "
                            "   objectdataid LIKE {} OR OudObjectDataID LIKE {} "
                            "ORDER BY objectdata.ObjectdataTaalCode, objectdata.objectdatarevisie".format(
                                masked_nrs_file, masked_nrs_file))
        return self.cursor.fetchall()

    def object_certificates(self, nrs_project, status="VRIJG"):
        """
        Returns a list of the certificates which are associated to the requested project.

        :param nrs_project: NRS number of the requested object (project)
        :param status: VRIJGEGEVEN only returns the certificates which are in the "vrijgegeven" status. "ALL"
            returns every related certificate, whichever status they are.
        :return:
        :rtype:
        """
        if status == "VALID":
            self.cursor.execute("SELECT * "
                                "FROM ObjectData "
                                "WHERE ObjectNr = %s "
                                "  AND CategorieSubID = 'D4' "
                                "  AND IsSchrijfbeveiligd = -1;", nrs_project)
        else:
            self.cursor.execute("SELECT * "
                                "FROM ObjectData "
                                "WHERE ObjectNr = %s "
                                "  AND CategorieSubID = 'D4';", nrs_project)
        return self.cursor.fetchall()

    def projects_with_certs_like(self, simil):
        self.cursor.execute("SELECT objectnr "
                            "FROM objectdata "
                            "WHERE categoriesubid = 'D4' "
                            "   AND objectnr "
                            "LIKE %s "
                            "GROUP BY objectnr", simil)
        return self.cursor.fetchall()

    def obtain_and_reserve_nrs_number(self, nrs_project, language, subcategory="D4", authorid=NRS_USERID, title=None):
        """
        Asking for a NRS project, and optionally for a category and author, obtain an objectdata_id and a full path
        on which the file is to be placed.

        Can generate several interrupts on errors:
            ValueError("NRS not properly working", "Not a single register (input_nieuweobjectdata)")

        :param nrs_project: NRS Project for which we are asking for a NRS number
        :param language: NRS code for the requested language
        :param subcategory: Document subcategory for which we are asking for a NRS number
        :param authorid: Id of the NRS user which will complete the insertion
        :return: tuple (objectdata_id, os_folder)

        """
        YES = -1
        NO = 0

        # NRS: verify there is a single record in the initial table
        self.cursor.execute("SELECT COUNT(*) FROM input_nieuweobjectdata;")
        # do whatever is needed for obtaining the number of records in a single variable
        number_of_registers = self.cursor.fetchone()[0]
        if number_of_registers != 1:
            raise ValueError("NRS not properly working. "
                             "Not a single register (input_nieuweobjectdata contains %s records)" % number_of_registers)
        # NRS: request the new code and obtain the result, just UPDATE, never INSERT!
        try:
            self.cursor.execute("UPDATE "
                                "   input_nieuweobjectdata "
                                "SET "
                                "   objectid ='{nrs_project}', "
                                "   auteurid={authorid}, "
                                "   subcategorie='{subcategorie}',"
                                "   objectdatataalcode='{language}', "
                                "   letterbeperking=0, "
                                "   ismultibestand=0;".format(nrs_project=nrs_project, authorid=authorid,
                                                              subcategorie=subcategory, language=language))
            self.cursor.execute("SELECT"
                                "  chk.chck_objectid, chk.chck_objectdatataalcode, "
                                "  chk.chck_subcategorieid, chk.chck_auteurid,"
                                "  data.ObjectDataID, data.BestandsDir, CONVERT(VARCHAR(120), data.CreatieDatum, 120) "
                                "FROM chck_input_nieuweobjectdata_q1 chk "
                                "JOIN output_nieuweobjectdata_q2_objectdata data"
                                "  ON 1 = 1;")
        except:
            # NRS: error writing
            #   input_nieuweobjectdata
            # or reading
            #   chck_input_nieuweobjectdata_q1,
            #   output_nieuweobjectdata_q2_objectdata
            raise ValueError("NRS not properly working", "Error requesting a new file code")
        # NRS: obtaining the results, we should get one and only one
        results = self.cursor.fetchall()
        if len(results) != 1:
            raise ValueError("NRS not properly working", "Not a single answer requesting a new file code")
        results = results[0]
        chk_object_id, chk_objectdatataalcode, chk_subcategorieid, chk_auteurid, nrs_number, file_path, creatie_datum = results
        if chk_object_id != 'OK':
            raise ValueError("Wrong or not existing NRS project request ({})".format(nrs_project))
        elif chk_objectdatataalcode != 'OK':
            raise ValueError("Wrong NRS language definition request ({})".format(language))
        elif chk_subcategorieid != 'OK':
            raise ValueError("Wrong NRS document subcategory request ({})".format(subcategory))
        elif chk_auteurid != 'OK':
            raise ValueError("Wrong NRS user request ({})".format(authorid))
        # create the record
        # part of these values are automatically obtained by transforming the results from previous SELECT query
        revisie = nrs_number[-1]
        category = subcategory[0]
        doc_number = nrs_number[-3:-1]
        full_filename = nrs_number + '.' + DOCX_EXTENSION
        is_xlat = ready = letterbeperking = multifile = protected = is_old = is_link = file_file_link = NO
        xlat_from = link_id = old_object = ''
        today = datetime.datetime.today()
        if title == None:
            title = '*** AUTOMATICALLY RESERVED BY DOCAUTO ON {day}/{month}/{year} ***'.format(
                day=today.day, month=today.month, year=today.year)
        comments = '{day:02}/{month:02}/{year} - Created by DOCAUTO\n'.format(day=today.day, month=today.month, year=today.year)

        try:
            self.cursor.execute("BEGIN TRANSACTION;")
        except:
            raise ValueError("NRS Database did not admit transaction.")

        # 4: insert the new objectdata metadata
        try:
            sql = "INSERT INTO ObjectData (" \
                            "   ObjectDataId, ObjectNr, ObjectdataTaalCode, ObjectDataRevisie, ObjectDataOms," \
                            "   IsVertaling, VertalingVanObjectDataId, Opmerking, AuteurID, CategorieID, " \
                            "   CategorieSubID, BestandGemaakt, BestandsNaam, BestandsDir, LetterBeperking, " \
                            "   IsMultiBestand, IsSchrijfBeveiligd, CreatiePersoneelID, IsOudNr, IsLinkFile," \
                            "   LinkObjectDataID, BestaandBestandGelinkt, OudObjectDataID, CreatieDatum, " \
                            "   ObjectDataVolgNr) " \
                            "VALUES (" \
                            "   '{nrs_number}', '{nrs_project}', '{language}', '{revisie}', '{title}'," \
                            "   {is_xlat}, '{xlat_from}', '{comments}', {authorid}, '{category}'," \
                            "   '{subcategory}', {ready}, '{filename}', '{file_path}', {letterbeperking}," \
                            "   {multifile}, {protected}, {creatiepersoneelid}, {is_old}, {is_link}," \
                            "   '{link_id}', {file_file_link}, '{old_object}', '{creatie_datum}'," \
                            "   '{doc_number}');".format(
                                                                                        nrs_number=nrs_number,
                                                                                        nrs_project=nrs_project,
                                                                                        language=language,
                                                                                        revisie=revisie,
                                                                                        title=title,
                                                                                        is_xlat=is_xlat,
                                                                                        xlat_from=xlat_from,
                                                                                        comments=comments,
                                                                                        authorid=authorid,
                                                                                        category=category,
                                                                                        subcategory=subcategory,
                                                                                        ready=ready,
                                                                                        filename=full_filename,
                                                                                        file_path=file_path,
                                                                                        letterbeperking=letterbeperking,
                                                                                        multifile=multifile,
                                                                                        protected=protected,
                                                                                        creatiepersoneelid=authorid,
                                                                                        is_old=is_old,
                                                                                        is_link=is_link,
                                                                                        link_id=link_id,
                                                                                        file_file_link=file_file_link,
                                                                                        old_object=old_object,
                                                                                        creatie_datum=creatie_datum,
                                                                                        doc_number=doc_number)
            self.cursor.execute(sql)
        except:
            self.cursor.execute("ROLLBACK")
            raise ValueError("NRS database did not accept new ObjectData")

        # logging
        try:
            # 5: Querying the data for logging
            self.cursor.execute("SELECT "
                                "   lognr, objectdataid, CONVERT(VARCHAR(120), logdatumtijd, 120), logpersoneelid, "
                                "   logtekst "
                                "FROM Output_NieuweObjectData_Q2_ObjectDataLog;")
            # NRS: obtaining the results, we should get one and only one
            results = self.cursor.fetchall()
            if len(results) != 1:
                self.cursor.execute("ROLLBACK")
                raise ValueError("NRS not properly working. "
                                 "Not a single register (Output_NieuweObjectData_Q2_ObjectDataLog)")
            lognr, objectdataid, logdatumtijd, logpersoneelid, logtekst = results[0]
            # 6. Insert the new log record
            self.cursor.execute("INSERT INTO ObjectDataLog ("
                            "lognr, objectdataid, logdatumtijd, logpersoneelid, logtekst) "
                            "VALUES ({lognr}, '{objectdataid}', '{logdatumtijd}', {logpersoneelid}, '{logtekst}')"
                            ";".format(lognr=lognr, objectdataid=objectdataid, logdatumtijd=logdatumtijd,
                                      logpersoneelid=logpersoneelid, logtekst=logtekst))
        except:
            self.cursor.execute("ROLLBACK")
            raise ValueError("NRS database did not accept ObjectData logging")

        try:
            # 7: Querying the data for linking + status
            self.cursor.execute("SELECT "
                                "   ObjectID, ObjectDataID, LinkStatusID, IsHoofdLink, "
                                "   CONVERT(VARCHAR(120), CreatieDatum, 120), CreatiePersoneelID, LinkBestandsDir, "
                                "   LinkBestandsNaam "
                                "FROM Output_NieuweObjectData_Q2_ObjectData_Link;")
            # NRS: obtaining the results, we should get one and only one
            results = self.cursor.fetchall()
            if len(results) != 1:
                self.cursor.execute("ROLLBACK")
                raise ValueError("NRS not properly working."
                                 "Not a single register (Output_NieuweObjectData_Q2_ObjectData_Link)")
            object_id, object_data_id, linkStatusID, isHoofdLink, creatie_datum, creatiePersoneelID, linkBestandsDir, \
                linkBestandsNaam = results[0]
            is_hoofd_link = YES
            link_bestands_dir = link_bestands_naam = ''
            IN_ONTWIKKELING = 1
            # 6. Insert the new link record
            self.cursor.execute("INSERT INTO ObjectData_Link ("
                                "   ObjectID, ObjectDataID, LinkStatusID, "
                                "   IsHoofdLink, CreatieDatum, CreatiePersoneelID, "
                                "   LinkBestandsDir, LinkBestandsNaam )"
                                "VALUES ("
                                "   '{object_id}', '{object_data_id}', {link_status_id}, "
                                "   {is_hoofd_link}, '{creatie_datum}', {creatie_personeel_id}, "
                                "   '{link_bestands_dir}', '{link_bestands_naam}')"
                                ";".format(object_id=object_id, object_data_id=object_data_id,
                                           link_status_id=IN_ONTWIKKELING, is_hoofd_link=is_hoofd_link,
                                           creatie_datum=creatie_datum, creatie_personeel_id=authorid,
                                           link_bestands_dir=link_bestands_dir, link_bestands_naam=link_bestands_naam))
        except:
            self.cursor.execute("ROLLBACK;")
            raise ValueError("NRS database did not accept ObjectDataLink logging+status")
        self.cursor.execute("COMMIT;")
        return nrs_number, file_path

    def release_reserve(self, nrs_number):
        # delete the reservation made by DOCAUTO with the nrs_number we are given
        sql = "SELECT ObjectDataOms FROM ObjectData WHERE ObjectDataID = '{nrs_number}';".format(nrs_number=nrs_number)
        self.cursor.execute(sql)
        results = self.cursor.fetchall()
        if len(results) != 1:
            # there is not one and only one record matching this criteria
            raise ValueError("There is more than a record for '{nrs_number}'".format(nrs_number=nrs_number))
        object_description = results[0][0]
        if 'RESERVED BY DOCAUTO' not in object_description:
            # there is a relevant record but it is not a reservation
            raise ValueError("There is no reservation for '{nrs_number}'".format(nrs_number=nrs_number))
        self.cursor.execute("BEGIN TRANSACTION;")
        try:
            sql = "DELETE FROM ObjectData WHERE ObjectDataID = '{nrs_number}'; "
            sql += "DELETE FROM ObjectDataLog WHERE ObjectDataID = '{nrs_number}'; "
            sql += "DELETE FROM ObjectData_Link WHERE ObjectDataID = '{nrs_number}'; "
            sql = sql.format(nrs_number=nrs_number)
            self.cursor.execute(sql)
            # if everything went well, then commit
            self.cursor.execute("COMMIT TRANSACTION;")
        except:
            self.cursor.execute("ROLLBACK;")
            raise ValueError("Could not release the reserve for '{nrs_number}'".format(nrs_number=nrs_number))

    def close(self):
        self.conn.close()


if __name__ == "__main__":

    nrs = NRSdb()
    nrs.close()

